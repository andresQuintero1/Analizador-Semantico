/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

import java.util.ArrayList;

/**
 *
 * @author FELIPE
 */
public class Producciones {
    
    private ArrayList<Token> tokens;
    private String tipo;

    public ArrayList<Token> getTokens() {
        return tokens;
    }

    
    public void addTokens(Token s){
        this.tokens.add(s);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Producciones() {
        this.tokens = new ArrayList<Token>();
    }
    
    public String getToken(int x){
        return this.tokens.get(x).getToken();
    }
    
    public String getlex(int x){
        return this.tokens.get(x).getLex();
    }
    
    
    
    
}

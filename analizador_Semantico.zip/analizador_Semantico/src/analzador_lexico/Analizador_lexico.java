/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

import java.util.ArrayList;
import java.util.Arrays;


/**
 *
 * @author FELIPE
 */
public class Analizador_lexico {

    /**
     * @param args the command line arguments
     */
    private final ArrayList<String> keyword=new ArrayList<>(Arrays.asList(
                                "false","true","none","and","as","assert","async",
                                "await","break","class","continue","def","del",
                                "elif","else","except","finally","for","from",
                                "global","import","if","in","is","lambda",
                                "nonlocal","pass","raise","return","try",
                                "with","while","yield","endw","endif","endfun","endfor"));
    private final ArrayList<String> constante=new ArrayList<>(Arrays.asList(
                                "None","notImplemented","Ellipsis","NaN","Inf",
                                "_debug_"));
    private final ArrayList<String> apertura=new ArrayList<>(Arrays.asList("(",
                                               "[","{"));
    private final ArrayList<String> cierre=new ArrayList<>(Arrays.asList(")","]"
                                                                ,"}"));
    private final ArrayList<String> simbolosEspeciales=new ArrayList<>(
                                    Arrays.asList("#","@",":",";","\""));
    private final ArrayList<String> aritmetico=new ArrayList<>(Arrays.asList("+",
                                                    "-","*","/","//","%","**"));
    private final ArrayList<String> relacional=new ArrayList<>(Arrays.asList("<",
                                                "<=",">",">=","!=","=="));
    private final ArrayList<String> logico=new ArrayList<>(Arrays.asList("or",
                                                "not","and"));
    private final ArrayList<String> asignacion=new ArrayList<>(Arrays.asList("=",
                                                "+=","-=","*=","/=","%=","**="));
    private final ArrayList<String> Bit_a_Bit=new ArrayList<>(Arrays.asList("&",
                                                "|","~","^","<<",">>"));
    
    private Token[] tokens;
    
    
    public Token[] Tokenize1(String frase){
        String[] chain=frase.split("\\s+");
        return this.identify(chain);
        
    }
    
        public Token[] Tokenize(String frase){
            
        this.tokens=new Token[frase.split("\\s+").length];
        String[] chain=frase.split("\n");
        this.identify(chain);
        return this.tokens;
        
    }
    
    public String toStrings1(String frase){
        Token[] tokens =this.Tokenize(frase);
        System.out.println(tokens.length);
        String mensaje1="";
        
        for (Token  x: tokens) {
            mensaje1 += x.getToken() + "  es un  " + x.getLex()+"\n";
        }
        
        return mensaje1;
        
    }
    
    public String toStrings(String frase){
        this.Tokenize(frase);
        String mensaje1="";
        System.out.println(tokens.length);
        for (Token  x: tokens) {
            System.out.println("entra una vez "+x.getToken());
            System.out.println("entra una vez "+x.getLex());
            mensaje1 += x.getToken() + "  es un  " + x.getLex()+"\n";
        }
        
        return mensaje1;
        
    }
    
    public Token[] identify(String[] chain1){
        String[] chain=null;
        int i=0;
        
        for(int j=0;j<chain1.length;j++){
            chain=chain1[j].split("\\s+");
//            if(chain.length<0){
//                j=j+1;
//                chain=chain1[j].split("\\s+");
//            }

            for(int k=0;k<chain.length;k++){
                if(this.constante.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"constant",j+1,k+1);
                    i++;
                }

                chain[k]=chain[k].toLowerCase();
                if(this.keyword.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"keyword",j+1,k+1);
                    i++;
                }else if(this.apertura.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"op parenthesis",j+1,k+1);
                    i++;
                }else if(this.cierre.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"cl parenthesis",j+1,k+1);
                    i++;
                }else if(this.simbolosEspeciales.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"Symbol",j+1,k+1);
                    i++;
                }else if(this.aritmetico.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"Aritmetic op",j+1,k+1);
                    i++;

                }else if(this.relacional.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"Relational op",j+1,k+1);
                    i++;
                }else if(this.asignacion.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"Assign op",j+1,k+1);
                    i++;
                }else if(this.logico.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"Logic op",j+1,k+1);
                    i++;
                }else if(this.Bit_a_Bit.contains(chain[k])){
                    tokens[i]=new Token(chain[k],"Bits op",j+1,k+1);
                    i++;
                }else if(chain[k].charAt(0)=="\"".charAt(0)&&
                        chain[k].charAt(chain[k].length()-1)=="\"".charAt(0) ){
                    tokens[i]=new Token(chain[k],"String",j+1,k+1);
                    i++;
                }else if(chain[k].matches("[+-]?\\d*(\\.\\d+)?")){
                    tokens[i]=new Token(chain[k],"Number",j+1,k+1);
                    i++;
                }else if(!this.simbolosEspeciales.contains(String.valueOf(
                        chain[k].charAt(0))) && !Character.isDigit(chain[k].charAt(0))){
                    tokens[i]=new Token(chain[k],"Identifier",j+1,k+1);
                    i++;

                }else{
                    tokens[i]=new Token(chain[k],"Out of Languaje",j+1,k+1);
                    i++;

                }
            }
        }
        
        return tokens;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Analizador_lexico an=new Analizador_lexico();
        Ingreso in=new Ingreso(an);
    }
    
}
